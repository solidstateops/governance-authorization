# SolidStateOps.Authorization.Service.Model.Invite

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long** |  | [optional] 
**Email** | **string** |  | [optional] 
**ConsumedBy** | **Guid?** |  | [optional] 
**ConsumedDate** | **DateTime?** |  | [optional] 
**CreatedById** | **Guid?** |  | [optional] 
**ModifiedById** | **Guid?** |  | [optional] 
**InviteRoles** | [**List&lt;InviteRole&gt;**](InviteRole.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

