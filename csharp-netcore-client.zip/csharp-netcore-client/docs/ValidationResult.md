# SolidStateOps.Authorization.Service.Model.ValidationResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsValid** | **bool** |  | [optional] [readonly] 
**Errors** | [**List&lt;ValidationFailure&gt;**](ValidationFailure.md) |  | [optional] [readonly] 
**RuleSetsExecuted** | **List&lt;string&gt;** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

