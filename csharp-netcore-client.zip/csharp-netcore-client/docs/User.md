# SolidStateOps.Service.Model.User

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **Guid** |  | [optional] 
**SubjectId** | **string** |  | [optional] 
**FullName** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**Archetype** | **string** |  | [optional] 
**LastLogin** | **DateTime?** |  | [optional] 
**Deleted** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

