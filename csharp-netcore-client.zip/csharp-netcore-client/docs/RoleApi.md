# Org.OpenAPITools.Api.RoleApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**RoleAdd**](RoleApi.md#roleadd) | **POST** /Role | 
[**RoleAddPermissionsConstraintsForRole**](RoleApi.md#roleaddpermissionsconstraintsforrole) | **PUT** /Role/{roleId}/Permission/{permissionId}/PermissionConstraint/{permissionConstraintId} | 
[**RoleDelete**](RoleApi.md#roledelete) | **DELETE** /Role/{roleId} | 
[**RoleDeletePermissionForRole**](RoleApi.md#roledeletepermissionforrole) | **DELETE** /Role/{roleId}/Permissions{permissionId} | 
[**RoleGetById**](RoleApi.md#rolegetbyid) | **GET** /Role/{roleId} | 
[**RoleGetPaginatedPermissionsForRole**](RoleApi.md#rolegetpaginatedpermissionsforrole) | **POST** /Role/{roleId}/Permissions/PagedSearch | 
[**RoleGetPaginatedUsersForRole**](RoleApi.md#rolegetpaginatedusersforrole) | **POST** /Role/{roleId}/Users/PagedSearch | 
[**RoleGetPermissionsConstraintsForRole**](RoleApi.md#rolegetpermissionsconstraintsforrole) | **GET** /Role/{roleId}/PermissionsConstraints | 
[**RoleGetPermissionsForRole**](RoleApi.md#rolegetpermissionsforrole) | **GET** /Role/{roleId}/Permissions | 
[**RoleGetUsersInRole**](RoleApi.md#rolegetusersinrole) | **GET** /Role/{roleId}/Users | 
[**RolePagedSearch**](RoleApi.md#rolepagedsearch) | **POST** /Role/PagedSearch | 
[**RoleSearch**](RoleApi.md#rolesearch) | **POST** /Role/Search | 
[**RoleUpdate**](RoleApi.md#roleupdate) | **PUT** /Role | 
[**RoleUpdatePermissions**](RoleApi.md#roleupdatepermissions) | **PUT** /Role/{roleId}/Permissions | 


<a name="roleadd"></a>
# **RoleAdd**
> RoleServiceResult RoleAdd (Role role = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleAddExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var role = new Role(); // Role |  (optional) 

            try
            {
                RoleServiceResult result = apiInstance.RoleAdd(role);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleAdd: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role** | [**Role**](Role.md)|  | [optional] 

### Return type

[**RoleServiceResult**](RoleServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="roleaddpermissionsconstraintsforrole"></a>
# **RoleAddPermissionsConstraintsForRole**
> RoleServiceResult RoleAddPermissionsConstraintsForRole (long roleId, long permissionId, long permissionConstraintId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleAddPermissionsConstraintsForRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 
            var permissionId = 789L;  // long | 
            var permissionConstraintId = 789L;  // long | 

            try
            {
                RoleServiceResult result = apiInstance.RoleAddPermissionsConstraintsForRole(roleId, permissionId, permissionConstraintId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleAddPermissionsConstraintsForRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 
 **permissionId** | **long**|  | 
 **permissionConstraintId** | **long**|  | 

### Return type

[**RoleServiceResult**](RoleServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="roledelete"></a>
# **RoleDelete**
> void RoleDelete (long roleId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 

            try
            {
                apiInstance.RoleDelete(roleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleDelete: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 

### Return type

void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="roledeletepermissionforrole"></a>
# **RoleDeletePermissionForRole**
> PermissionServiceResult RoleDeletePermissionForRole (long roleId, long permissionId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleDeletePermissionForRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 
            var permissionId = 789L;  // long | 

            try
            {
                PermissionServiceResult result = apiInstance.RoleDeletePermissionForRole(roleId, permissionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleDeletePermissionForRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 
 **permissionId** | **long**|  | 

### Return type

[**PermissionServiceResult**](PermissionServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolegetbyid"></a>
# **RoleGetById**
> RoleServiceResult RoleGetById (long roleId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleGetByIdExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 

            try
            {
                RoleServiceResult result = apiInstance.RoleGetById(roleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleGetById: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 

### Return type

[**RoleServiceResult**](RoleServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolegetpaginatedpermissionsforrole"></a>
# **RoleGetPaginatedPermissionsForRole**
> RolePermissionServiceSearchResult RoleGetPaginatedPermissionsForRole (long roleId, PagedSearch pagedSearch = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleGetPaginatedPermissionsForRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 
            var pagedSearch = new PagedSearch(); // PagedSearch |  (optional) 

            try
            {
                RolePermissionServiceSearchResult result = apiInstance.RoleGetPaginatedPermissionsForRole(roleId, pagedSearch);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleGetPaginatedPermissionsForRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 
 **pagedSearch** | [**PagedSearch**](PagedSearch.md)|  | [optional] 

### Return type

[**RolePermissionServiceSearchResult**](RolePermissionServiceSearchResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **400** | Bad Request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolegetpaginatedusersforrole"></a>
# **RoleGetPaginatedUsersForRole**
> UserServiceSearchResult RoleGetPaginatedUsersForRole (long roleId, PagedSearch pagedSearch = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleGetPaginatedUsersForRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 
            var pagedSearch = new PagedSearch(); // PagedSearch |  (optional) 

            try
            {
                UserServiceSearchResult result = apiInstance.RoleGetPaginatedUsersForRole(roleId, pagedSearch);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleGetPaginatedUsersForRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 
 **pagedSearch** | [**PagedSearch**](PagedSearch.md)|  | [optional] 

### Return type

[**UserServiceSearchResult**](UserServiceSearchResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **400** | Bad Request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolegetpermissionsconstraintsforrole"></a>
# **RoleGetPermissionsConstraintsForRole**
> PermissionConstraintIEnumerableServiceResult RoleGetPermissionsConstraintsForRole (long roleId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleGetPermissionsConstraintsForRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 

            try
            {
                PermissionConstraintIEnumerableServiceResult result = apiInstance.RoleGetPermissionsConstraintsForRole(roleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleGetPermissionsConstraintsForRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 

### Return type

[**PermissionConstraintIEnumerableServiceResult**](PermissionConstraintIEnumerableServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolegetpermissionsforrole"></a>
# **RoleGetPermissionsForRole**
> RolePermissionIEnumerableServiceResult RoleGetPermissionsForRole (long roleId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleGetPermissionsForRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 

            try
            {
                RolePermissionIEnumerableServiceResult result = apiInstance.RoleGetPermissionsForRole(roleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleGetPermissionsForRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 

### Return type

[**RolePermissionIEnumerableServiceResult**](RolePermissionIEnumerableServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolegetusersinrole"></a>
# **RoleGetUsersInRole**
> UserIEnumerableServiceResult RoleGetUsersInRole (long roleId)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleGetUsersInRoleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 

            try
            {
                UserIEnumerableServiceResult result = apiInstance.RoleGetUsersInRole(roleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleGetUsersInRole: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 

### Return type

[**UserIEnumerableServiceResult**](UserIEnumerableServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolepagedsearch"></a>
# **RolePagedSearch**
> RoleServiceSearchResult RolePagedSearch (PagedSearch pagedSearch = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RolePagedSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var pagedSearch = new PagedSearch(); // PagedSearch |  (optional) 

            try
            {
                RoleServiceSearchResult result = apiInstance.RolePagedSearch(pagedSearch);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RolePagedSearch: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pagedSearch** | [**PagedSearch**](PagedSearch.md)|  | [optional] 

### Return type

[**RoleServiceSearchResult**](RoleServiceSearchResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |
| **400** | Bad Request |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rolesearch"></a>
# **RoleSearch**
> RoleIEnumerableServiceResult RoleSearch (RoleSearch roleSearch = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleSearch = new RoleSearch(); // RoleSearch |  (optional) 

            try
            {
                RoleIEnumerableServiceResult result = apiInstance.RoleSearch(roleSearch);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleSearch: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleSearch** | [**RoleSearch**](RoleSearch.md)|  | [optional] 

### Return type

[**RoleIEnumerableServiceResult**](RoleIEnumerableServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="roleupdate"></a>
# **RoleUpdate**
> RoleServiceResult RoleUpdate (Role role = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var role = new Role(); // Role |  (optional) 

            try
            {
                RoleServiceResult result = apiInstance.RoleUpdate(role);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleUpdate: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role** | [**Role**](Role.md)|  | [optional] 

### Return type

[**RoleServiceResult**](RoleServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="roleupdatepermissions"></a>
# **RoleUpdatePermissions**
> RoleServiceResult RoleUpdatePermissions (long roleId, List<long> requestBody = null)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class RoleUpdatePermissionsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new RoleApi(config);
            var roleId = 789L;  // long | 
            var requestBody = new List<long>(); // List<long> |  (optional) 

            try
            {
                RoleServiceResult result = apiInstance.RoleUpdatePermissions(roleId, requestBody);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling RoleApi.RoleUpdatePermissions: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **roleId** | **long**|  | 
 **requestBody** | [**List&lt;long&gt;**](long.md)|  | [optional] 

### Return type

[**RoleServiceResult**](RoleServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/_*+json
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

