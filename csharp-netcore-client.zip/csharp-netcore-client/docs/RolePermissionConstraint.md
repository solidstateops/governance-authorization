# Org.OpenAPITools.Model.RolePermissionConstraint

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PermissionConstraint** | [**PermissionConstraint**](PermissionConstraint.md) |  | [optional] 
**RolePermission** | [**RolePermission**](RolePermission.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

