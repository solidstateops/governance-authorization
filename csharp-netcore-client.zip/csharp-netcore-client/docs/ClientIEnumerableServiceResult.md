# SolidStateOps.Service.Model.ClientIEnumerableServiceResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | **List&lt;string&gt;** |  | [optional] 
**Value** | [**List&lt;ModelClient&gt;**](ModelClient.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

