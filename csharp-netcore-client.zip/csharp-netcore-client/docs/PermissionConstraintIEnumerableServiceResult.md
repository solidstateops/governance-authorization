# SolidStateOps.Authorization.Service.Model.PermissionConstraintIEnumerableServiceResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | **List&lt;string&gt;** |  | [optional] 
**Value** | [**List&lt;PermissionConstraint&gt;**](PermissionConstraint.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

