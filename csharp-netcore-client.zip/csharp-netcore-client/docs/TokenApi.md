# SolidStateOps.Authorization.Service.Api.TokenApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TokenHasPermission**](TokenApi.md#tokenhaspermission) | **GET** /Token/HasPermission/{areaName}/{permissionName} | 
[**TokenListAreas**](TokenApi.md#tokenlistareas) | **GET** /Token/ListAreas | 
[**TokenListPermissions**](TokenApi.md#tokenlistpermissions) | **GET** /Token/ListPermissions/{areaName} | 


<a name="tokenhaspermission"></a>
# **TokenHasPermission**
> bool TokenHasPermission (string areaName, string permissionName)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Authorization.Service.Api;
using SolidStateOps.Authorization.Service.Client;
using SolidStateOps.Authorization.Service.Model;

namespace Example
{
    public class TokenHasPermissionExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TokenApi(config);
            var areaName = "areaName_example";  // string | 
            var permissionName = "permissionName_example";  // string | 

            try
            {
                bool result = apiInstance.TokenHasPermission(areaName, permissionName);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TokenApi.TokenHasPermission: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **areaName** | **string**|  | 
 **permissionName** | **string**|  | 

### Return type

**bool**

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="tokenlistareas"></a>
# **TokenListAreas**
> AreaIEnumerableServiceResult TokenListAreas ()



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Authorization.Service.Api;
using SolidStateOps.Authorization.Service.Client;
using SolidStateOps.Authorization.Service.Model;

namespace Example
{
    public class TokenListAreasExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TokenApi(config);

            try
            {
                AreaIEnumerableServiceResult result = apiInstance.TokenListAreas();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TokenApi.TokenListAreas: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AreaIEnumerableServiceResult**](AreaIEnumerableServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="tokenlistpermissions"></a>
# **TokenListPermissions**
> PermissionIEnumerableServiceResult TokenListPermissions (string areaName)



### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Authorization.Service.Api;
using SolidStateOps.Authorization.Service.Client;
using SolidStateOps.Authorization.Service.Model;

namespace Example
{
    public class TokenListPermissionsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            // Configure OAuth2 access token for authorization: oauth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TokenApi(config);
            var areaName = "areaName_example";  // string | 

            try
            {
                PermissionIEnumerableServiceResult result = apiInstance.TokenListPermissions(areaName);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling TokenApi.TokenListPermissions: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **areaName** | **string**|  | 

### Return type

[**PermissionIEnumerableServiceResult**](PermissionIEnumerableServiceResult.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

