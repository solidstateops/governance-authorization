# Org.OpenAPITools.Model.UserServiceSearchResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FilteredCount** | **long** |  | [optional] 
**SearchResults** | [**List&lt;User&gt;**](User.md) |  | [optional] 
**SearchRequest** | [**PagedSearch**](PagedSearch.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

