# SolidStateOps.Service.Model.PermissionSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ids** | **List&lt;long&gt;** |  | [optional] 
**Names** | **List&lt;string&gt;** |  | [optional] 
**AreaNames** | **List&lt;string&gt;** |  | [optional] 
**UserIds** | **List&lt;Guid&gt;** |  | [optional] 
**SubjectIds** | **List&lt;string&gt;** |  | [optional] 
**ClientIds** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

