# Org.OpenAPITools.Model.RolePermission

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Role** | [**Role**](Role.md) |  | [optional] 
**Permission** | [**Permission**](Permission.md) |  | [optional] 
**RolePermissionConstraints** | [**List&lt;RolePermissionConstraint&gt;**](RolePermissionConstraint.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

