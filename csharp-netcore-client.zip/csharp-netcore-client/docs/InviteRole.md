# SolidStateOps.Service.Model.InviteRole

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InviteId** | **long** |  | [optional] 
**RoleName** | **string** |  | [optional] 
**RoleId** | **long** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

