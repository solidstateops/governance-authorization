# Org.OpenAPITools.Model.UserSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PageSize** | **int** |  | [optional] [default to 20]
**PageOffset** | **int** |  | [optional] 
**Ids** | **List&lt;Guid&gt;** |  | [optional] 
**SubjectIds** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

