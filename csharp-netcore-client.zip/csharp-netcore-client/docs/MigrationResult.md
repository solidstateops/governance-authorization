# Org.OpenAPITools.Model.MigrationResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddedAreas** | **List&lt;string&gt;** |  | [optional] 
**AddedPermissions** | [**List&lt;AddedPermission&gt;**](AddedPermission.md) |  | [optional] 
**AddedRoles** | **List&lt;string&gt;** |  | [optional] 
**AddedRolePermissions** | [**List&lt;AddedRolePermission&gt;**](AddedRolePermission.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

