# SolidStateOps.Authorization.Service.Model.ValidationFailure

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PropertyName** | **string** |  | [optional] 
**ErrorMessage** | **string** |  | [optional] 
**AttemptedValue** | **Object** |  | [optional] 
**CustomState** | **Object** |  | [optional] 
**Severity** | **Severity** |  | [optional] 
**ErrorCode** | **string** |  | [optional] 
**FormattedMessageArguments** | **List&lt;Object&gt;** |  | [optional] 
**FormattedMessagePlaceholderValues** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

