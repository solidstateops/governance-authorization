# Org.OpenAPITools.Model.PagedSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SearchTerm** | **string** |  | [optional] 
**Skip** | **int** |  | [optional] 
**Take** | **int** |  | [optional] 
**SortTerm** | **string** |  | [optional] 
**SortDirection** | **ListSortDirection** |  | [optional] 
**WithDeleted** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

