# SolidStateOps.Authorization.Service.Model.RoleServiceSearchResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FilteredCount** | **long** |  | [optional] 
**SearchResults** | [**List&lt;Role&gt;**](Role.md) |  | [optional] 
**SearchRequest** | [**PagedSearch**](PagedSearch.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

