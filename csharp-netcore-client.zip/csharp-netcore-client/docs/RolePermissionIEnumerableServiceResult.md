# SolidStateOps.Service.Model.RolePermissionIEnumerableServiceResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | **List&lt;string&gt;** |  | [optional] 
**Value** | [**List&lt;RolePermission&gt;**](RolePermission.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

